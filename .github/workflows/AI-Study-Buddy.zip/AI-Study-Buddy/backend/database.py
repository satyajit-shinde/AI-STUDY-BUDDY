"""SQLite database layer - simple functions, no ORM.

Tables: users, documents, quiz_results, study_log.
Only one real user (id=1) exists for now. Sample users fill the leaderboard.
To use a bigger database later (PostgreSQL/MySQL), only this file needs to change.
"""
import json
import sqlite3
from datetime import date, timedelta
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "study_buddy.db"
ME = 1  # id of the current (only) user

SAMPLE_USERS = [  # name, xp, avg quiz score, streak
    ("Aditya", 2450, 91, 12), ("Rohit", 2210, 85, 9),
    ("Pratik", 1840, 78, 5), ("Neha", 1620, 88, 7), ("Kunal", 1190, 72, 3),
]


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def query(sql, args=(), one=False):
    conn = connect()
    try:
        rows = conn.execute(sql, args).fetchall()
    finally:
        conn.close()
    return (rows[0] if rows else None) if one else rows


def execute(sql, args=()):
    conn = connect()
    try:
        with conn:  # commits on success, rolls back on error
            return conn.execute(sql, args).lastrowid
    finally:
        conn.close()


def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = connect()
    try:
        with conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY, name TEXT NOT NULL, xp INTEGER DEFAULT 0,
                streak INTEGER DEFAULT 0, best_streak INTEGER DEFAULT 0,
                last_study_date TEXT, is_sample INTEGER DEFAULT 0, sample_score INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, filename TEXT,
                stored_name TEXT, pages INTEGER, words INTEGER, size_kb INTEGER,
                text TEXT, uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE TABLE IF NOT EXISTS quiz_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, doc_id INTEGER,
                topic TEXT, difficulty TEXT, total INTEGER, correct INTEGER,
                topic_stats TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE TABLE IF NOT EXISTS study_log (
                user_id INTEGER, day TEXT, minutes INTEGER DEFAULT 0, PRIMARY KEY (user_id, day));
            """)
            if not conn.execute("SELECT 1 FROM users WHERE id=?", (ME,)).fetchone():
                conn.execute("INSERT INTO users (id, name) VALUES (?, 'Student')", (ME,))
                for name, xp, score, streak in SAMPLE_USERS:
                    conn.execute("INSERT INTO users (name, xp, streak, best_streak, is_sample, sample_score) "
                                 "VALUES (?,?,?,?,1,?)", (name, xp, streak, streak, score))
    finally:
        conn.close()


# ---------- user / streak / xp ----------

def get_user():
    return query("SELECT * FROM users WHERE id=?", (ME,), one=True)


def set_name(name):
    execute("UPDATE users SET name=? WHERE id=?", (name, ME))


def add_xp(amount):
    execute("UPDATE users SET xp = xp + ? WHERE id=?", (amount, ME))


def touch_study(minutes=0):
    """Call whenever the student does something. Updates streak and today's study minutes."""
    today = date.today()
    user = get_user()
    if user["last_study_date"] != today.isoformat():
        yesterday = (today - timedelta(days=1)).isoformat()
        streak = user["streak"] + 1 if user["last_study_date"] == yesterday else 1
        best = max(user["best_streak"], streak)
        execute("UPDATE users SET streak=?, best_streak=?, last_study_date=? WHERE id=?",
                (streak, best, today.isoformat(), ME))
    if minutes:
        execute("INSERT INTO study_log (user_id, day, minutes) VALUES (?,?,?) "
                "ON CONFLICT(user_id, day) DO UPDATE SET minutes = minutes + excluded.minutes",
                (ME, today.isoformat(), minutes))


def current_streak(user):
    """A streak only counts if the student studied today or yesterday."""
    last = user["last_study_date"]
    if last in (date.today().isoformat(), (date.today() - timedelta(days=1)).isoformat()):
        return user["streak"]
    return 0


# ---------- documents ----------

def add_document(filename, stored_name, pages, text, size_kb):
    return execute(
        "INSERT INTO documents (user_id, filename, stored_name, pages, words, size_kb, text) "
        "VALUES (?,?,?,?,?,?,?)",
        (ME, filename, stored_name, pages, len(text.split()), size_kb, text))


def list_documents():
    return query("""
        SELECT d.id, d.filename, d.pages, d.words, d.size_kb, d.uploaded_at,
               COUNT(q.id) AS quiz_count,
               COALESCE(MAX(q.correct * 100.0 / q.total), 0) AS best_score
        FROM documents d LEFT JOIN quiz_results q ON q.doc_id = d.id
        WHERE d.user_id=? GROUP BY d.id ORDER BY d.id DESC""", (ME,))


def get_document(doc_id):
    return query("SELECT * FROM documents WHERE id=? AND user_id=?", (doc_id, ME), one=True)


def delete_document(doc_id):
    execute("DELETE FROM documents WHERE id=? AND user_id=?", (doc_id, ME))


# ---------- quizzes ----------

def save_quiz(doc_id, topic, difficulty, total, correct, topic_stats):
    execute("INSERT INTO quiz_results (user_id, doc_id, topic, difficulty, total, correct, topic_stats) "
            "VALUES (?,?,?,?,?,?,?)",
            (ME, doc_id, topic, difficulty, total, correct, json.dumps(topic_stats)))


def reset_history():
    """Clear study history. Returns stored file names so the caller can delete the PDFs."""
    files = [r["stored_name"] for r in query("SELECT stored_name FROM documents WHERE user_id=?", (ME,))]
    for table in ("documents", "quiz_results", "study_log"):
        execute(f"DELETE FROM {table} WHERE user_id=?", (ME,))
    execute("UPDATE users SET xp=0, streak=0, best_streak=0, last_study_date=NULL WHERE id=?", (ME,))
    return files
