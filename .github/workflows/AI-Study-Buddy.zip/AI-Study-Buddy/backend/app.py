"""Flask server: API routes + serves the frontend.

Run:  python app.py   (from the backend folder)  ->  http://127.0.0.1:5000
"""
import os
import re
import uuid
from datetime import date, timedelta
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")  # must run before importing ai.py settings are used

import ai          # noqa: E402
import database as db   # noqa: E402
import pdf_reader  # noqa: E402

UPLOAD_DIR = BASE_DIR / "uploads"
FRONTEND_DIR = BASE_DIR / "frontend"
MAX_MB = 20

app = Flask(__name__, static_folder=str(FRONTEND_DIR), static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = MAX_MB * 1024 * 1024
CORS(app)  # lets you also open frontend/index.html directly from disk
UPLOAD_DIR.mkdir(exist_ok=True)
db.init_db()


# ---------------------------------------------------------------- helpers

def clean(text, limit=500):
    """Sanitize user text: drop control characters, trim, limit length."""
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(text or "")).strip()
    return text[:limit]


def error(message, status=400):
    return jsonify({"error": message}), status


def doc_from(data):
    """Find the document named in the request. Returns (doc, None) or (None, error_response)."""
    try:
        doc = db.get_document(int(data.get("doc_id")))
    except (TypeError, ValueError):
        doc = None
    return (doc, None) if doc else (None, error("Select an uploaded PDF first.", 404))


def doc_info(row):
    return {"id": row["id"], "filename": row["filename"], "pages": row["pages"], "words": row["words"],
            "size_kb": row["size_kb"], "uploaded_at": row["uploaded_at"]}


@app.errorhandler(413)
def too_big(_):
    return error(f"File is too large. The limit is {MAX_MB} MB.", 413)


@app.errorhandler(500)
def server_error(_):
    return error("Something went wrong on the server. Please try again.", 500)


# ---------------------------------------------------------------- pages

@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.get("/api/status")
def status():
    user = db.get_user()
    return jsonify({"ai_mode": "live" if ai.is_configured() else "demo", "name": user["name"]})


# ---------------------------------------------------------------- upload

@app.post("/api/upload")
def upload():
    file = request.files.get("file")
    if not file or not file.filename:
        return error("No file received.")
    original = secure_filename(file.filename) or "document.pdf"
    if not original.lower().endswith(".pdf"):
        return error("Only PDF files are allowed.")

    stored = f"{uuid.uuid4().hex}.pdf"  # random name: no overwrites, no path tricks
    path = UPLOAD_DIR / stored
    file.save(path)
    try:
        if not pdf_reader.looks_like_pdf(path):
            raise ValueError("This file is not a real PDF.")
        text, pages = pdf_reader.extract_text(path)
    except ValueError as e:
        path.unlink(missing_ok=True)
        return error(str(e), 422)

    doc_id = db.add_document(original, stored, pages, text, path.stat().st_size // 1024)
    db.add_xp(20)
    db.touch_study()
    return jsonify({"document": doc_info(db.get_document(doc_id)), "xp": 20}), 201


@app.get("/api/documents")
def documents():
    rows = db.list_documents()
    return jsonify({"documents": [dict(r, best_score=round(r["best_score"])) for r in rows]})


@app.delete("/api/documents/<int:doc_id>")
def delete_document(doc_id):
    doc = db.get_document(doc_id)
    if not doc:
        return error("Document not found.", 404)
    (UPLOAD_DIR / doc["stored_name"]).unlink(missing_ok=True)
    db.delete_document(doc_id)
    return jsonify({"ok": True})


# ---------------------------------------------------------------- AI features

@app.post("/api/summary")
def summary():
    data = request.get_json(silent=True) or {}
    doc, err = doc_from(data)
    if err:
        return err
    mode = "simple" if data.get("mode") == "simple" else "full"
    try:
        result = ai.summarize(doc["text"], mode)
    except ai.AIError as e:
        return error(str(e), 502)
    db.add_xp(10)
    db.touch_study()
    return jsonify({"summary": result, "ai_mode": "live" if ai.is_configured() else "demo"})


@app.post("/api/ask")
def ask():
    data = request.get_json(silent=True) or {}
    doc, err = doc_from(data)
    if err:
        return err
    question = clean(data.get("question"), 500)
    if not question:
        return error("Type a question first.")
    history = [{"role": "assistant" if t.get("role") == "assistant" else "user", "text": clean(t.get("text"), 1500)}
               for t in (data.get("history") or [])[-6:] if isinstance(t, dict) and t.get("text")]
    try:
        reply = ai.answer(doc["text"], question, history)
    except ai.AIError as e:
        return error(str(e), 502)
    db.add_xp(5)
    db.touch_study()
    return jsonify({"answer": reply})


@app.post("/api/quiz")
def quiz():
    data = request.get_json(silent=True) or {}
    doc, err = doc_from(data)
    if err:
        return err
    count = int(data.get("count", 5)) if str(data.get("count", 5)).isdigit() else 5
    count = count if count in (5, 10, 20) else 5
    difficulty = data.get("difficulty") if data.get("difficulty") in ("Easy", "Medium", "Hard") else "Medium"
    topic = clean(data.get("topic"), 80)
    try:
        questions = ai.make_quiz(doc["text"], count, difficulty, topic)
    except ai.AIError as e:
        return error(str(e), 502)
    return jsonify({"questions": questions, "ai_mode": "live" if ai.is_configured() else "demo"})


@app.post("/api/quiz/submit")
def quiz_submit():
    """The browser sends [{topic, correct}, ...]; totals are recomputed here."""
    data = request.get_json(silent=True) or {}
    doc, err = doc_from(data)
    if err:
        return err
    results = [r for r in (data.get("results") or []) if isinstance(r, dict)][:20]
    if not results:
        return error("No quiz answers received.")
    stats = {}
    for r in results:
        topic = clean(r.get("topic"), 60) or "General"
        c, t = stats.get(topic, (0, 0))
        stats[topic] = (c + (1 if r.get("correct") else 0), t + 1)
    correct = sum(c for c, _ in stats.values())
    weak = [t for t, (c, n) in stats.items() if c / n < 0.6]
    difficulty = data.get("difficulty") if data.get("difficulty") in ("Easy", "Medium", "Hard") else "Medium"
    db.save_quiz(doc["id"], clean(data.get("topic"), 80) or "Whole document", difficulty,
                 len(results), correct, stats)
    xp = correct * 10 + (20 if correct == len(results) else 0)  # bonus for a perfect score
    db.add_xp(xp)
    db.touch_study()
    return jsonify({"xp": xp, "weak_topics": weak})


# ---------------------------------------------------------------- progress

@app.get("/api/progress")
def progress():
    user = db.get_user()
    today = date.today()
    docs = db.list_documents()
    quizzes = db.query("SELECT * FROM quiz_results WHERE user_id=? ORDER BY id DESC", (db.ME,))
    avg = round(sum(q["correct"] * 100 / q["total"] for q in quizzes) / len(quizzes)) if quizzes else 0

    logs = {r["day"]: r["minutes"] for r in db.query("SELECT day, minutes FROM study_log WHERE user_id=?", (db.ME,))}
    week = []
    for i in range(6, -1, -1):
        d = today - timedelta(days=i)
        week.append({"day": d.strftime("%a"), "minutes": logs.get(d.isoformat(), 0)})
    total_minutes = sum(logs.values())

    # Topic accuracy across all quizzes
    import json
    topics = {}
    for q in quizzes:
        for topic, (c, n) in json.loads(q["topic_stats"] or "{}").items():
            old = topics.get(topic, [0, 0])
            topics[topic] = [old[0] + c, old[1] + n]
    ranked = [{"topic": t, "accuracy": round(c * 100 / n), "questions": n} for t, (c, n) in topics.items()]
    strong = sorted([t for t in ranked if t["accuracy"] >= 70], key=lambda t: -t["accuracy"])[:6]
    weak = sorted([t for t in ranked if t["accuracy"] < 70], key=lambda t: t["accuracy"])[:6]

    # Overall progress = average of quiz skill, study time (6h = 100%) and documents (5 = 100%)
    overall = round((avg + min(100, total_minutes / 3.6) + min(100, len(docs) * 20)) / 3)
    return jsonify({
        "name": user["name"], "xp": user["xp"], "documents": len(docs), "avg_score": avg,
        "total_minutes": total_minutes, "today_minutes": logs.get(today.isoformat(), 0),
        "streak": db.current_streak(user), "best_streak": user["best_streak"], "overall": overall,
        "week": week, "strong_topics": strong, "weak_topics": weak,
        "history": [{"topic": q["topic"], "difficulty": q["difficulty"], "correct": q["correct"],
                     "total": q["total"], "date": q["created_at"][:10]} for q in quizzes[:10]],
    })


@app.post("/api/study-time")
def study_time():
    """The browser calls this once a minute while the tab is open and visible."""
    minutes = 1
    db.touch_study(minutes)
    return jsonify({"ok": True})


@app.get("/api/leaderboard")
def leaderboard():
    rows = db.query("SELECT * FROM users ORDER BY xp DESC, id")
    out = []
    for rank, u in enumerate(rows, start=1):
        if u["is_sample"]:
            score, streak = u["sample_score"], u["streak"]
        else:
            quizzes = db.query("SELECT correct, total FROM quiz_results WHERE user_id=?", (u["id"],))
            score = round(sum(q["correct"] * 100 / q["total"] for q in quizzes) / len(quizzes)) if quizzes else 0
            streak = db.current_streak(u)
        out.append({"rank": rank, "name": u["name"], "xp": u["xp"], "score": score,
                    "streak": streak, "is_me": u["id"] == db.ME})
    return jsonify({"leaderboard": out})


# ---------------------------------------------------------------- settings

@app.post("/api/profile")
def profile():
    name = clean((request.get_json(silent=True) or {}).get("name"), 30)
    if not name:
        return error("Name cannot be empty.")
    db.set_name(name)
    return jsonify({"name": name})


@app.post("/api/reset")
def reset():
    for stored in db.reset_history():
        (UPLOAD_DIR / stored).unlink(missing_ok=True)
    return jsonify({"ok": True})


if __name__ == "__main__":
    mode = "LIVE AI" if ai.is_configured() else "DEMO MODE (no API key in .env)"
    print(f"\n  AI Study Buddy running in {mode}\n  Open http://127.0.0.1:5000\n")
    app.run(host="127.0.0.1", port=5000, debug=True)
