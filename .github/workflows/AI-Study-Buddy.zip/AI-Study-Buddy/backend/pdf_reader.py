"""PDF helpers: validate a file and extract its text with pypdf."""
import re
from pypdf import PdfReader


def looks_like_pdf(path):
    """Real PDFs start with the bytes %PDF - a stronger check than the file extension."""
    with open(path, "rb") as f:
        return f.read(5).startswith(b"%PDF")


def extract_text(path):
    """Return (text, page_count). Raises ValueError with a friendly message on failure."""
    try:
        reader = PdfReader(path)
        if reader.is_encrypted:
            # Many PDFs are "encrypted" with an empty password - try that first.
            if not reader.decrypt(""):
                raise ValueError("This PDF is password-protected. Remove the password and try again.")
        pages = []
        for page in reader.pages:
            try:
                pages.append(page.extract_text() or "")
            except Exception:
                pages.append("")  # skip a broken page instead of failing everything
    except ValueError:
        raise
    except Exception:
        raise ValueError("This file could not be read as a PDF. It may be corrupted.")

    text = "\n".join(pages)
    text = re.sub(r"[ \t]+", " ", text)       # collapse spaces
    text = re.sub(r"\n{3,}", "\n\n", text)    # collapse blank lines
    text = text.strip()
    if len(text) < 50:
        raise ValueError("No readable text found. This looks like a scanned PDF (images only).")
    return text, len(pages)
