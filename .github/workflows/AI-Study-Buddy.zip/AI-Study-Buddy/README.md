# AI Study Buddy 🤖📚

Upload your PDF notes, then get AI summaries, ask questions about them, and take auto-generated quizzes. Track your progress, streaks and XP.

## Features
- Dashboard with documents, quiz average, study time, streak, today's goal, overall progress and quick buttons
- PDF upload: drag & drop, PDF-only and 20 MB validation, upload progress, text extraction
- AI summary: short, detailed, key points, definitions, formulas, exam points, "Explain simply"
- Ask AI: chat about your PDF; says clearly when an answer is outside the material
- Quiz generator: 5/10/20 questions, Easy/Medium/Hard, optional topic, feedback, final report with weak topics
- Progress page with 7-day chart, quiz history, strong/weak topics, current and best streak
- Leaderboard (sample students + you), settings (theme, goal, difficulty, name, clear history), toasts, mobile menu
- **Demo mode**: works without an API key (simple text-based answers and a built-in question bank)

## Screenshots
_Add screenshots here: `docs/dashboard.png`, `docs/quiz.png`_

## Tech stack
Frontend: HTML5, CSS3, vanilla JavaScript · Backend: Python 3.10+, Flask · PDF: pypdf · Database: SQLite · AI: Anthropic API

## Folder structure
```
AI-Study-Buddy/
├── frontend/   index.html, style.css, script.js
├── backend/    app.py (routes), ai.py (AI + demo mode), pdf_reader.py, database.py, requirements.txt
├── uploads/    uploaded PDFs (created automatically, git-ignored)
├── data/       questions.json (demo quiz bank) + study_buddy.db (created automatically)
├── .env        your secret API key (git-ignored)
├── .gitignore
└── README.md
```

## Installation
Windows (PowerShell):
```
cd AI-Study-Buddy
python -m venv venv
venv\Scripts\activate
pip install -r backend/requirements.txt
```
macOS / Linux:
```
cd AI-Study-Buddy
python3 -m venv venv
source venv/bin/activate
pip install -r backend/requirements.txt
```
Required packages: Flask, flask-cors, python-dotenv, pypdf, anthropic.

## .env setup
Open `.env` in the project root and paste your key:
```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxx
ANTHROPIC_MODEL=claude-haiku-5-5
```
Get a key at https://console.anthropic.com/ (API Keys). Leave it empty to use demo mode. Never share or commit `.env`.

## Run the backend
```
cd backend
python app.py
```
The terminal shows `LIVE AI` or `DEMO MODE`.

## Open the frontend
Go to **http://127.0.0.1:5000** (Flask serves the frontend). Opening `frontend/index.html` directly also works while the backend is running.

## How the AI works
1. You upload a PDF; `pdf_reader.py` extracts its text and stores it in SQLite.
2. For each request, `ai.py` sends the PDF text (up to ~30,000 characters; for long PDFs the chunks that best match your question or topic) plus a prompt to the AI API from the **server**.
3. Prompts tell the AI to use only your material, say when something is outside it, and return JSON for summaries and quizzes.
4. Without an API key, simple built-in logic answers instead (demo mode). API errors show a clear message and never crash the app.

## Future improvements
User accounts and login · real multi-user leaderboard · OCR for scanned PDFs · flashcards · spaced repetition · export summaries as PDF · streaming chat answers
