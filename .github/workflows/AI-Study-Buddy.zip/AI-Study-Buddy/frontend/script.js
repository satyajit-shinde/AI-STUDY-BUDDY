// ===============================
// AI STUDY BUDDY - FRONTEND LOGIC
// ===============================
// The browser never sees the AI key. Everything goes through the Flask API.

// If you open index.html directly from disk, talk to the Flask server on port 5000.
const API = location.protocol === "file:" ? "http://127.0.0.1:5000" : "";

// ---------- small helpers ----------
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const store = {
    get(key, fallback) {
        try { const v = localStorage.getItem(key); return v === null ? fallback : JSON.parse(v); }
        catch { return fallback; }
    },
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage full/blocked */ } }
};

function esc(text) {
    return String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// Tiny safe markdown: escapes HTML first, then supports **bold**, `code` and "- " bullet lists.
function renderMd(text) {
    const lines = esc(text).split("\n");
    let html = "", inList = false;
    for (const line of lines) {
        const bullet = line.match(/^\s*[-*•]\s+(.*)/);
        if (bullet && !inList) { html += "<ul>"; inList = true; }
        if (!bullet && inList) { html += "</ul>"; inList = false; }
        const fmt = (bullet ? bullet[1] : line).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`(.+?)`/g, "<code>$1</code>");
        html += bullet ? `<li>${fmt}</li>` : (fmt.trim() ? `<p>${fmt}</p>` : "");
    }
    return html + (inList ? "</ul>" : "");
}

function toast(message, type = "info") {
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    el.textContent = message;
    $("#toasts").appendChild(el);
    setTimeout(() => el.remove(), 3800);
}

async function api(path, options = {}) {
    let res;
    try { res = await fetch(API + path, options); }
    catch { throw new Error("Cannot reach the server. Is the Flask backend running?"); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Server error (${res.status})`);
    return data;
}
const post = (path, body) => api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

function fmtTime(min) { return min < 60 ? `${min}m` : `${(min / 60).toFixed(1)}h`; }
function loadingHTML(text) { return `<div class="loading"><div class="spinner"></div><span>${esc(text)}</span></div>`; }
function errorHTML(msg) { return `<div class="error-state">⚠️ ${esc(msg)}</div>`; }

// ---------- state ----------
let docs = [];
let activeDocId = store.get("activeDocId", null);
const settings = Object.assign(
    { theme: "light", notify: true, goal: 60, difficulty: "Medium" }, store.get("settings", {}));
let userName = "Student";

// ---------- navigation ----------
const titles = {
    dashboard: "Dashboard", pdf: "Upload Study Material", summary: "AI Summary", ask: "Ask AI",
    quiz: "Quiz Challenge", progress: "My Progress", leaderboard: "Leaderboard", settings: "Settings"
};

function openSection(name) {
    $$(".section").forEach((s) => s.classList.remove("active-section"));
    $("#" + name)?.classList.add("active-section");
    $$(".nav-item[data-section]").forEach((i) => i.classList.toggle("active", i.dataset.section === name));
    $("#pageTitle").textContent = titles[name] || "Dashboard";
    closeMenu();
    if (name === "dashboard" || name === "progress") loadProgress();
    if (name === "leaderboard") loadLeaderboard();
    if (name === "pdf" || name === "summary" || name === "ask" || name === "quiz") loadDocs();
    window.scrollTo(0, 0);
}

// Every element with data-section navigates (sidebar items and dashboard buttons).
$$("[data-section]").forEach((el) => el.addEventListener("click", () => openSection(el.dataset.section)));

function closeMenu() { $("#sidebar").classList.remove("open"); $("#backdrop").classList.remove("show"); }
$("#menuBtn").addEventListener("click", () => { $("#sidebar").classList.add("open"); $("#backdrop").classList.add("show"); });
$("#backdrop").addEventListener("click", closeMenu);

// ---------- theme & settings ----------
function applyTheme() {
    document.body.classList.toggle("dark", settings.theme === "dark");
    $("#themeBtn").innerHTML = settings.theme === "dark" ? "☀️ <span>Light Mode</span>" : "🌙 <span>Dark Mode</span>";
    $("#setTheme").value = settings.theme;
}
function saveSettings() { store.set("settings", settings); }

$("#themeBtn").addEventListener("click", () => { settings.theme = settings.theme === "dark" ? "light" : "dark"; saveSettings(); applyTheme(); });
$("#setTheme").addEventListener("change", (e) => { settings.theme = e.target.value; saveSettings(); applyTheme(); });
$("#setNotify").addEventListener("change", (e) => { settings.notify = e.target.checked; saveSettings(); toast(settings.notify ? "Study reminders on" : "Study reminders off"); });
$("#setGoal").addEventListener("change", (e) => { settings.goal = Number(e.target.value); saveSettings(); loadProgress(); toast("Daily goal updated", "success"); });
$("#setDifficulty").addEventListener("change", (e) => { settings.difficulty = e.target.value; saveSettings(); $("#quizDifficulty").value = settings.difficulty; toast("Default difficulty saved", "success"); });

$("#saveName").addEventListener("click", async () => {
    try {
        const res = await post("/api/profile", { name: $("#setName").value });
        setName(res.name); toast("Profile saved", "success");
    } catch (e) { toast(e.message, "error"); }
});

$("#clearHistory").addEventListener("click", async () => {
    if (!confirm("Delete all documents, quiz results, study time, streaks and XP? This cannot be undone.")) return;
    try {
        await api("/api/reset", { method: "POST" });
        activeDocId = null; store.set("activeDocId", null);
        sessionStorage.removeItem("chat"); chat.length = 0; renderChat();
        resetQuizUI(); $("#summaryOutput").innerHTML = emptySummary();
        await loadDocs(); await loadProgress();
        toast("Study history cleared", "success");
    } catch (e) { toast(e.message, "error"); }
});

function setName(name) {
    userName = name;
    $("#topAvatar").textContent = name.trim().slice(0, 1).toUpperCase() || "S";
    $("#welcomeTitle").textContent = `Hi ${name}, ready to learn something new?`;
    $("#setName").value = name;
}

function applySettingsToForm() {
    $("#setNotify").checked = settings.notify;
    $("#setGoal").value = String(settings.goal);
    $("#setDifficulty").value = settings.difficulty;
    $("#quizDifficulty").value = settings.difficulty;
}

// ---------- documents ----------
async function loadDocs() {
    try {
        docs = (await api("/api/documents")).documents;
    } catch (e) { docs = []; toast(e.message, "error"); }
    if (!docs.some((d) => d.id === activeDocId)) activeDocId = docs[0]?.id ?? null;
    store.set("activeDocId", activeDocId);
    renderDocs();
}

function setActiveDoc(id) { activeDocId = Number(id); store.set("activeDocId", activeDocId); renderDocs(); }

function renderDocs() {
    // dropdowns on summary / ask / quiz pages
    $$(".doc-select").forEach((sel) => {
        sel.innerHTML = docs.length
            ? docs.map((d) => `<option value="${d.id}">${esc(d.filename)}</option>`).join("")
            : `<option value="">No documents yet</option>`;
        sel.value = activeDocId ?? "";
        sel.onchange = () => setActiveDoc(sel.value);
    });

    // document list on the upload page
    $("#docList").innerHTML = docs.length ? docs.map((d) => `
        <div class="course clickable" data-id="${d.id}">
            <div class="course-icon">📄</div>
            <div class="course-info">
                <h4>${esc(d.filename)}</h4>
                <div class="doc-meta"><span>${d.pages} pages</span><span>${d.words.toLocaleString()} words</span><span>${d.size_kb} KB</span><span>${esc(d.uploaded_at.slice(0, 10))}</span></div>
            </div>
            <div class="doc-actions">
                ${d.id === activeDocId ? '<span class="active-tag">Active</span>' : ""}
                <button class="icon-btn" data-del="${d.id}" title="Delete document" aria-label="Delete">🗑️</button>
            </div>
        </div>`).join("")
        : `<div class="empty"><div>📭</div><p>No documents yet. Upload your first PDF above.</p></div>`;

    $$("#docList .course").forEach((row) => row.addEventListener("click", () => setActiveDoc(row.dataset.id)));
    $$("#docList [data-del]").forEach((btn) => btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        if (!confirm("Delete this document?")) return;
        try { await api(`/api/documents/${btn.dataset.del}`, { method: "DELETE" }); toast("Document deleted", "success"); await loadDocs(); }
        catch (err) { toast(err.message, "error"); }
    }));

    // dashboard "continue learning"
    $("#continueList").innerHTML = docs.length ? docs.slice(0, 3).map((d) => `
        <div class="course clickable" data-open="${d.id}">
            <div class="course-icon">📘</div>
            <div class="course-info">
                <h4>${esc(d.filename)}</h4>
                <div class="progress-bar"><div style="width:${d.best_score}%"></div></div>
                <small>${d.quiz_count ? `Best quiz score ${d.best_score}%` : "No quiz taken yet - start one!"}</small>
            </div>
        </div>`).join("")
        : `<div class="empty"><div>📚</div><p>Upload a PDF to start learning.</p></div>`;
    $$("#continueList [data-open]").forEach((row) => row.addEventListener("click", () => { setActiveDoc(row.dataset.open); openSection("summary"); }));
}

// Returns true when a document is selected, otherwise sends the user to the upload page.
function requireDoc() {
    if (activeDocId) return true;
    toast("Upload a PDF first", "error");
    openSection("pdf");
    return false;
}

// ---------- upload ----------
const dropZone = $("#dropZone");
const pdfInput = $("#pdfInput");

function showUploadMsg(text, kind) { const m = $("#uploadMsg"); m.textContent = text; m.className = `msg ${kind || ""}`; }

function uploadFile(file) {
    $("#fileName").textContent = `${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)`;
    showUploadMsg("", "");
    if (!file.name.toLowerCase().endsWith(".pdf") || (file.type && file.type !== "application/pdf")) {
        return showUploadMsg("❌ Only PDF files are allowed.", "err");
    }
    if (file.size > 20 * 1024 * 1024) return showUploadMsg("❌ File is larger than 20 MB.", "err");
    if (file.size === 0) return showUploadMsg("❌ This file is empty.", "err");

    const form = new FormData();
    form.append("file", file);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", API + "/api/upload");
    $("#uploadProgress").classList.remove("hidden");
    $("#uploadBar").style.width = "0%";
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) $("#uploadBar").style.width = `${(e.loaded / e.total) * 100}%`; };
    xhr.onload = async () => {
        $("#uploadProgress").classList.add("hidden");
        let data = {};
        try { data = JSON.parse(xhr.responseText); } catch { /* not JSON */ }
        if (xhr.status === 201) {
            activeDocId = data.document.id; store.set("activeDocId", activeDocId);
            showUploadMsg(`✅ Uploaded! ${data.document.pages} pages, ${data.document.words.toLocaleString()} words read. +${data.xp} XP`, "ok");
            toast("PDF uploaded and read", "success");
            await loadDocs(); loadProgress();
        } else {
            showUploadMsg(`❌ ${data.error || "Upload failed."}`, "err");
        }
    };
    xhr.onerror = () => { $("#uploadProgress").classList.add("hidden"); showUploadMsg("❌ Cannot reach the server. Is Flask running?", "err"); };
    xhr.send(form);
}

pdfInput.addEventListener("change", () => { if (pdfInput.files[0]) uploadFile(pdfInput.files[0]); pdfInput.value = ""; });
["dragenter", "dragover"].forEach((ev) => dropZone.addEventListener(ev, (e) => { e.preventDefault(); dropZone.classList.add("drag"); }));
["dragleave", "drop"].forEach((ev) => dropZone.addEventListener(ev, (e) => { e.preventDefault(); dropZone.classList.remove("drag"); }));
dropZone.addEventListener("drop", (e) => { if (e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0]); });

// ---------- summary ----------
const summaryOutput = $("#summaryOutput");
const emptySummary = () => `<div class="empty"><div>🧠</div><p>Your summary will appear here.</p></div>`;

function summaryCard(title, body, wide) { return `<div class="sum-card${wide ? " wide" : ""}"><h4>${title}</h4>${body}</div>`; }
function listHTML(items, empty) { return items?.length ? `<ul>${items.map((i) => `<li>${esc(i)}</li>`).join("")}</ul>` : `<p>${empty}</p>`; }

async function runSummary(mode, button, label) {
    if (!requireDoc()) return;
    button.disabled = true; button.textContent = "⏳ Working…";
    summaryOutput.innerHTML = loadingHTML(mode === "simple" ? "Writing a simple explanation…" : "Reading your document and writing the summary…");
    try {
        const { summary: s } = await post("/api/summary", { doc_id: activeDocId, mode });
        if (mode === "simple") {
            summaryOutput.innerHTML = `<div class="sum-grid">${summaryCard("💡 Explained simply", renderMd(s.simple), true)}</div>`;
        } else {
            summaryOutput.innerHTML = `<div class="sum-grid">
                ${summaryCard("⚡ Short summary", `<p>${esc(s.short_summary)}</p>`, true)}
                ${summaryCard("📖 Detailed summary", `<p>${esc(s.detailed_summary).replace(/\n+/g, "</p><p>")}</p>`, true)}
                ${summaryCard("⭐ Important points", listHTML(s.important_points, "None found."))}
                ${summaryCard("🎓 Exam-focused points", listHTML(s.exam_points, "None found."))}
                ${summaryCard("📚 Key definitions", s.definitions?.length ? `<ul>${s.definitions.map((d) => `<li><b>${esc(d.term)}:</b> ${esc(d.meaning)}</li>`).join("")}</ul>` : "<p>No definitions found.</p>")}
                ${summaryCard("🧮 Formulas", s.formulas?.length ? `<ul>${s.formulas.map((f) => `<li><code>${esc(f)}</code></li>`).join("")}</ul>` : "<p>No formulas in this material.</p>")}
            </div>`;
        }
        loadProgress();
    } catch (e) {
        summaryOutput.innerHTML = errorHTML(e.message);
        toast(e.message, "error");
    }
    button.disabled = false; button.textContent = label;
}
$("#summaryBtn").addEventListener("click", (e) => runSummary("full", e.currentTarget, "✨ Generate summary"));
$("#simpleBtn").addEventListener("click", (e) => runSummary("simple", e.currentTarget, "💡 Explain simply"));

// ---------- ask AI ----------
const chat = []; // conversation for this browser session (kept in sessionStorage)
try { chat.push(...JSON.parse(sessionStorage.getItem("chat") || "[]")); } catch { /* ignore */ }
const chatBox = $("#chatMessages");

function messageHTML(role, html) {
    const isUser = role === "user";
    return `<div class="message ${isUser ? "user" : "ai"}"><div class="message-avatar">${isUser ? "👤" : "🤖"}</div>
        <div class="bubble"><strong>${isUser ? "You" : "StudyBuddy AI"}</strong>${html}</div></div>`;
}

function renderChat() {
    chatBox.innerHTML = messageHTML("assistant", "<p>Hi! Pick a document and ask me anything about it. If the answer isn't in your PDF, I'll tell you.</p>")
        + chat.map((m) => messageHTML(m.role, m.role === "user" ? `<p>${esc(m.text)}</p>` : renderMd(m.text))).join("");
    chatBox.scrollTop = chatBox.scrollHeight;
}
function saveChat() { sessionStorage.setItem("chat", JSON.stringify(chat.slice(-30))); }

async function askQuestion() {
    const input = $("#questionInput");
    const question = input.value.trim();
    if (!question || !requireDoc()) return;
    const history = chat.slice(-6);
    chat.push({ role: "user", text: question });
    input.value = ""; input.disabled = true; $("#askBtn").disabled = true;
    renderChat();
    chatBox.insertAdjacentHTML("beforeend", messageHTML("assistant", `<p class="dots"><span></span><span></span><span></span></p>`));
    chatBox.scrollTop = chatBox.scrollHeight;
    try {
        const { answer } = await post("/api/ask", { doc_id: activeDocId, question, history });
        chat.push({ role: "assistant", text: answer });
    } catch (e) {
        chat.push({ role: "assistant", text: `⚠️ ${e.message}` });
        toast(e.message, "error");
    }
    saveChat(); renderChat();
    input.disabled = false; $("#askBtn").disabled = false; input.focus();
}
$("#askBtn").addEventListener("click", askQuestion);
$("#questionInput").addEventListener("keydown", (e) => { if (e.key === "Enter") askQuestion(); });
$("#clearChat").addEventListener("click", () => { chat.length = 0; saveChat(); renderChat(); toast("Chat cleared"); });

// ---------- quiz ----------
let quiz = null; // { questions, index, score, results, answered, doc, difficulty, topic, count }

function showQuizPanel(name) {
    ["quizSetup", "quizPlay", "quizResult"].forEach((id) => $("#" + id).classList.toggle("hidden", id !== name));
}
function resetQuizUI() { quiz = null; showQuizPanel("quizSetup"); }

async function startQuiz() {
    if (!requireDoc()) return;
    const btn = $("#startQuiz");
    const opts = { count: Number($("#quizCount").value), difficulty: $("#quizDifficulty").value, topic: $("#quizTopic").value.trim() };
    btn.disabled = true; btn.textContent = "⏳ Building your quiz…";
    try {
        const { questions, ai_mode } = await post("/api/quiz", { doc_id: activeDocId, ...opts });
        if (!questions.length) throw new Error("No questions could be created. Try a different topic.");
        quiz = { ...opts, questions, index: 0, score: 0, results: [], answered: false, doc: activeDocId };
        if (ai_mode === "demo") toast("Demo mode: sample questions, not from your PDF. Add an API key for real quizzes.");
        showQuizPanel("quizPlay"); showQuestion();
    } catch (e) { toast(e.message, "error"); }
    btn.disabled = false; btn.textContent = "🎯 Start quiz";
}

function showQuestion() {
    const q = quiz.questions[quiz.index];
    quiz.answered = false;
    $("#questionNumber").textContent = `Question ${quiz.index + 1} of ${quiz.questions.length}`;
    $("#quizScore").textContent = `Score: ${quiz.score}`;
    $("#quizBar").style.width = `${(quiz.index / quiz.questions.length) * 100}%`;
    $("#question").textContent = q.question;
    $("#feedback").classList.add("hidden");
    $("#nextBtn").classList.add("hidden");
    $("#nextBtn").textContent = quiz.index === quiz.questions.length - 1 ? "See results" : "Next question";
    const box = $("#options"); box.innerHTML = "";
    q.options.forEach((text, i) => {
        const b = document.createElement("button");
        b.innerHTML = `<b>${"ABCD"[i]}</b><span></span>`;
        b.querySelector("span").textContent = text;
        b.addEventListener("click", () => answerQuestion(i));
        box.appendChild(b);
    });
}

function answerQuestion(choice) {
    if (quiz.answered) return;
    quiz.answered = true;
    const q = quiz.questions[quiz.index];
    const right = choice === q.answer;
    if (right) quiz.score++;
    quiz.results.push({ topic: q.topic, correct: right });
    [...$("#options").children].forEach((btn, i) => {
        btn.disabled = true;
        if (i === q.answer) btn.classList.add("correct");
        else if (i === choice) btn.classList.add("wrong");
    });
    $("#quizScore").textContent = `Score: ${quiz.score}`;
    const fb = $("#feedback");
    fb.className = `feedback ${right ? "good" : "bad"}`;
    fb.innerHTML = `<b>${right ? "✅ Correct!" : "❌ Not quite."}</b> ${esc(q.explanation)}`;
    $("#nextBtn").classList.remove("hidden");
}

$("#nextBtn").addEventListener("click", () => {
    if (quiz.index < quiz.questions.length - 1) { quiz.index++; showQuestion(); }
    else finishQuiz();
});

async function finishQuiz() {
    $("#quizBar").style.width = "100%";
    const total = quiz.questions.length, correct = quiz.score, pct = Math.round((correct / total) * 100);
    let weak = [], xp = 0;
    try {
        const res = await post("/api/quiz/submit", { doc_id: quiz.doc, topic: quiz.topic, difficulty: quiz.difficulty, results: quiz.results });
        weak = res.weak_topics; xp = res.xp;
        loadProgress();
    } catch (e) { toast("Result could not be saved: " + e.message, "error"); }

    let tips;
    if (pct >= 80) tips = "Excellent work! Try a harder difficulty or a different topic to keep growing.";
    else if (pct >= 50) tips = "Good effort. Read the explanations for the questions you missed, then retake the quiz.";
    else tips = "Review the AI summary of this document first, then try an Easy quiz to build confidence.";
    if (weak.length) tips += ` Spend extra time on: ${weak.join(", ")}.`;

    $("#quizResult").innerHTML = `
        <div class="result-top"><p class="muted">Quiz complete 🎉</p><div class="big">${pct}%</div><p>${correct} of ${total} correct${xp ? ` · +${xp} XP` : ""}</p></div>
        <div class="result-grid"><div><strong>${correct}/${total}</strong><span>Total score</span></div>
            <div><strong>${correct}</strong><span>Correct</span></div><div><strong>${total - correct}</strong><span>Wrong</span></div></div>
        <div class="result-block"><h4>Weak topics</h4><div class="chips">${weak.length ? weak.map((t) => `<span class="chip bad">${esc(t)}</span>`).join("") : '<span class="chip good">None - nice!</span>'}</div></div>
        <div class="result-block"><h4>Suggestions</h4><p class="muted">${esc(tips)}</p></div>
        <div class="btn-row"><button class="primary-btn" id="retryQuiz">🔁 Retake quiz</button><button class="ghost-btn" id="newQuiz">New quiz</button></div>`;
    showQuizPanel("quizResult");
    $("#retryQuiz").addEventListener("click", () => { showQuizPanel("quizSetup"); startQuiz(); });
    $("#newQuiz").addEventListener("click", resetQuizUI);
}
$("#startQuiz").addEventListener("click", startQuiz);

// ---------- progress, dashboard, leaderboard ----------
async function loadProgress() {
    try {
        const p = await api("/api/progress");
        setName(p.name);
        $("#xpBadge").textContent = `${p.xp} XP`;
        // dashboard
        $("#dDocs").textContent = p.documents;
        $("#dScore").textContent = `${p.avg_score}%`;
        $("#dTime").textContent = fmtTime(p.total_minutes);
        $("#dStreak").textContent = `${p.streak} ${p.streak === 1 ? "day" : "days"}`;
        $("#dOverall").textContent = `${p.overall}%`;
        $("#dOverallBar").style.width = `${p.overall}%`;
        const goalPct = Math.min(100, Math.round((p.today_minutes / settings.goal) * 100));
        $("#goalCircle").style.background = `conic-gradient(var(--primary) ${goalPct}%, var(--track) 0)`;
        $("#goalPct").textContent = `${goalPct}%`;
        $("#goalText").textContent = `${p.today_minutes} of ${settings.goal} minutes today`;
        $("#goalSub").textContent = goalPct >= 100 ? "Goal reached - great job! 🎉" : "Keep your streak alive 🔥";
        // progress page
        $("#pOverall").textContent = `${p.overall}%`; $("#pOverallBar").style.width = `${p.overall}%`;
        $("#pScore").textContent = `${p.avg_score}%`; $("#pScoreBar").style.width = `${p.avg_score}%`;
        $("#pTime").textContent = fmtTime(p.total_minutes);
        $("#pToday").textContent = `${p.today_minutes} min today`;
        $("#pStreak").textContent = p.streak; $("#pBest").textContent = p.best_streak;

        const max = Math.max(10, ...p.week.map((d) => d.minutes));
        $("#weekChart").innerHTML = p.week.map((d) => `<div class="bar-col"><span>${d.minutes}m</span><div class="bar" style="height:${(d.minutes / max) * 100}%"></div><span>${d.day}</span></div>`).join("");
        const chips = (list, kind, empty) => list.length ? list.map((t) => `<span class="chip ${kind}">${esc(t.topic)} · ${t.accuracy}%</span>`).join("") : `<span class="muted">${empty}</span>`;
        $("#strongTopics").innerHTML = chips(p.strong_topics, "good", "Take a few quizzes to find your strengths.");
        $("#weakTopics").innerHTML = chips(p.weak_topics, "bad", "No weak topics yet.");
        $("#quizHistory").innerHTML = p.history.length ? p.history.map((h) => `
            <div class="history-row"><div><strong>${esc(h.topic)}</strong><small>${esc(h.difficulty)} · ${esc(h.date)}</small></div>
            <div><strong>${h.correct}/${h.total}</strong><small>${Math.round(h.correct * 100 / h.total)}%</small></div></div>`).join("")
            : `<div class="empty"><div>🎯</div><p>No quizzes yet. Take your first one!</p></div>`;

        const key = "goalToast-" + new Date().toDateString();
        if (goalPct >= 100 && settings.notify && !store.get(key, false)) { store.set(key, true); toast("🎉 Daily study goal reached!", "success"); }
    } catch (e) { /* server may be offline; the upload/AI actions show their own errors */ }
}

async function loadLeaderboard() {
    const box = $("#leaderList");
    box.innerHTML = loadingHTML("Loading leaderboard…");
    try {
        const { leaderboard } = await api("/api/leaderboard");
        const medals = ["🥇", "🥈", "🥉"];
        box.innerHTML = leaderboard.map((u) => `
            <div class="leader ${u.is_me ? "me" : ""}">
                <span class="rank">${medals[u.rank - 1] || u.rank}</span>
                <div class="leader-avatar">${esc(u.name.slice(0, 2).toUpperCase())}</div>
                <div class="who"><strong>${esc(u.name)}${u.is_me ? " (you)" : ""}</strong></div>
                <div class="stats"><div><b>${u.xp}</b>XP</div><div><b>${u.score}%</b>quiz</div><div><b>${u.streak}🔥</b>streak</div></div>
            </div>`).join("");
    } catch (e) { box.innerHTML = errorHTML(e.message); }
}

// ---------- study timer: counts one minute each minute the tab is visible ----------
setInterval(() => {
    if (document.visibilityState === "visible") post("/api/study-time", {}).then(() => {
        if ($("#dashboard").classList.contains("active-section") || $("#progress").classList.contains("active-section")) loadProgress();
    }).catch(() => {});
}, 60000);

// ---------- start ----------
async function init() {
    applyTheme(); applySettingsToForm(); renderChat(); summaryOutput.innerHTML = emptySummary();
    try {
        const s = await api("/api/status");
        const pill = $("#modePill");
        pill.className = `mode-pill ${s.ai_mode}`;
        pill.textContent = s.ai_mode === "live" ? "● AI connected" : "● Demo mode (no API key)";
    } catch (e) {
        $("#modePill").textContent = "● Server offline";
        toast(e.message, "error");
    }
    await loadDocs();
    await loadProgress();
    if (settings.notify) toast(`📚 Time to study! Your goal today: ${settings.goal} minutes.`);
}
init();
